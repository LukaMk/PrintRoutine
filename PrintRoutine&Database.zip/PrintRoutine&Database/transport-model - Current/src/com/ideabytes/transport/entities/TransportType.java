package com.ideabytes.transport.entities;

public enum TransportType {
    PASENGERANDCARGO,
    CARGOONLY
}
