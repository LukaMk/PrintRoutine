package com.ideabytes.transport.entities;

public enum ShipmentType {
    RADIOACTIVE,
    NONRADIOACTIVE
}
